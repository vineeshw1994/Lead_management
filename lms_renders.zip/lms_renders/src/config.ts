const config = {
    API_URL: "https://nextedigital.in.net/public/api",
};

export default config;
