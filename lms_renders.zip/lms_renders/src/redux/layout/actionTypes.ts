// actionTypes.js

export const SET_LEAD_COUNT = 'SET_LEAD_COUNT';
export const SET_LEADS = 'SET_LEADS';
